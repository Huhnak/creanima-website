document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute("href")).scrollIntoView({
            behavior: "smooth",
        });
    });
});

const canvas = document.getElementById("constellation");
const ctx = canvas.getContext("2d");

// SVG-данные для звёздочки
const starSvgPath = "M10,0 A10,10 0 1,1 10,20 A10,10 0 1,1 10,0"; 
const starSize = 10;

// Привязываем звёзды к секциям на странице
const sections = [['#hero','#star-1'], ['#about','#star-2'], ['#ar','#star-3'], ['#works','#star-4'], ['#team','#star-5']];

// Координаты звёзд (будут заполнены динамически из секций)
let stars = [
    { x: 0.2, y: 0.1 },
    { x: 0.78, y: 0.223 },
    { x: 0.78, y: 0.422 },
    { x: 0.4, y: 0.7 },
    { x: 0.8, y: 0.9 }
];

// Переменные для анимации звёздочки
let starPosition = 0;
let targetStarPosition = 0;
let animationFrameId = null;
let currentStarX = 0;
let currentStarY = 0;
let previousStarX = 0;
let previousStarY = 0;
let rotationAngle = 0;

const starSpeed = 0.05; 

// Переменные для следа
const trail = [];
const maxTrailLength = 30; 
const trailFadeFactor = 0.95; 

/**
 * Вычисляет абсолютный центр каждой секции и преобразует его
 * в относительные (процентные) координаты для Canvas.
 */
function calculateStarPositions() {
    const documentHeight = document.documentElement.scrollHeight;
    const documentWidth = window.innerWidth;
    
    const newStars = sections.map((selector, index) => {
        // selector[1] - ID элемента, который вы отслеживаете (напр., '#star-1')
        const element = document.querySelector(selector[1]); 
        
        if (!element) return stars[index] || { x: 0.5, y: 0.5 };

        const rect = element.getBoundingClientRect();
        
        // 1. АБСОЛЮТНАЯ ВЕРХНЯЯ КООРДИНАТА ЭЛЕМЕНТА:
        // rect.top (относительно viewport) + window.scrollY (прокрутка)
        const absoluteTop = rect.top + window.scrollY;
        
        // 2. АБСОЛЮТНАЯ ЦЕНТРАЛЬНАЯ КООРДИНАТА:
        // Absolute Top + половина высоты элемента
        const centerY = absoluteTop + rect.height / 2;
        
        // 3. АБСОЛЮТНАЯ ГОРИЗОНТАЛЬНАЯ ЦЕНТРАЛЬНАЯ КООРДИНАТА:
        const centerX = rect.left + window.scrollX + rect.width / 2;
        
        // 4. ПРЕОБРАЗОВАНИЕ В ПРОЦЕНТЫ:
        const x_percent = centerX / documentWidth;
        const y_percent = centerY / documentHeight;

        return { x: x_percent, y: y_percent };
    });

    stars = newStars;
}

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = document.documentElement.scrollHeight;
    
    // 1. Пересчитываем позиции звезд
    calculateStarPositions(); 

    // 2. ВАЖНОЕ ИЗМЕНЕНИЕ: Обновляем текущее абсолютное положение летающей звезды 
    // на основе ее текущей дробной позиции (starPosition) и новых размеров.
    if (stars.length > 1) {
        const segmentLength = 1 / (stars.length - 1);
        const currentSegmentIndex = Math.floor(starPosition / segmentLength);
        const t = (starPosition % segmentLength) / segmentLength;

        if (currentSegmentIndex < stars.length - 1) {
            const startStar = stars[currentSegmentIndex];
            const endStar = stars[currentSegmentIndex + 1];

            currentStarX = (startStar.x * (1 - t) + endStar.x * t) * canvas.width;
            currentStarY = (startStar.y * (1 - t) + endStar.y * t) * canvas.height;
        } else {
            // Если звезда достигла последней точки
            currentStarX = stars[stars.length - 1].x * canvas.width;
            currentStarY = stars[stars.length - 1].y * canvas.height;
        }
    } else {
        // Заглушка, если звёзд нет
        currentStarX = 0;
        currentStarY = 0;
    }
    // Конец НОВОГО блока

    draw();
    
    // 3. ПЕРЕЗАПУСК АНИМАЦИИ: Гарантируем, что анимация возобновится после изменения размера.
    if (starPosition !== targetStarPosition) {
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
        }
        animateStar();
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Рисуем линии созвездия
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    stars.forEach((star, i) => {
        const x = star.x * canvas.width;
        const y = star.y * canvas.height;
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    ctx.stroke();

    // Рисуем неподвижные звёзды
    stars.forEach(star => {
        const x = star.x * canvas.width;
        const y = star.y * canvas.height;
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, Math.PI * 2);
        ctx.fillStyle = "white";
        ctx.shadowColor = "white";
        ctx.shadowBlur = 10;
        ctx.fill();
    });

    // Рисуем летающую звёздочку и её след
    if (stars.length > 1) {
        const segmentLength = 1 / (stars.length - 1);
        const currentSegmentIndex = Math.floor(starPosition / segmentLength);
        const t = (starPosition % segmentLength) / segmentLength;
        
        // ВАЖНО: Если анимация активна (starPosition < 1), пересчитываем координаты 
        // для корректного движения по новой траектории
        if (starPosition < 1) {
            if (currentSegmentIndex < stars.length - 1) {
                const startStar = stars[currentSegmentIndex];
                const endStar = stars[currentSegmentIndex + 1];

                const x = (startStar.x * (1 - t) + endStar.x * t) * canvas.width;
                const y = (startStar.y * (1 - t) + endStar.y * t) * canvas.height;
                
                // Только если координаты изменились (в процессе анимации)
                if (currentStarX !== 0 && currentStarY !== 0) {
                     const dx = x - currentStarX;
                     const dy = y - currentStarY;
                     rotationAngle = Math.atan2(dy, dx) + Math.PI / 2;
                }
                
                previousStarX = currentStarX;
                previousStarY = currentStarY;
                currentStarX = x;
                currentStarY = y;
            } else {
                 // Если звезда достигла последней точки
                 currentStarX = stars[stars.length - 1].x * canvas.width;
                 currentStarY = stars[stars.length - 1].y * canvas.height;
            }
        }
       
        // Добавляем текущее положение звезды в массив следа
        trail.push({ x: currentStarX, y: currentStarY });
        if (trail.length > maxTrailLength) {
            trail.shift(); 
        }

        // Рисуем след
        for (let i = 0; i < trail.length; i++) {
            const trailPoint = trail[i];
            const alpha = (i / trail.length) * trailFadeFactor; 
            const size = (i / trail.length) * (starSize / 1.1); 

            ctx.beginPath();
            ctx.arc(trailPoint.x, trailPoint.y, size / 2, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
            ctx.shadowColor = `rgba(255, 255, 255, ${alpha * 0.5})`;
            ctx.shadowBlur = 5;
            ctx.fill();
        }
        
        // Рисуем саму звёздочку
        ctx.save();
        ctx.translate(currentStarX, currentStarY);
        ctx.rotate(rotationAngle);

        ctx.beginPath();
        const path = new Path2D(starSvgPath);
        ctx.transform(starSize / 19, 0, 0, starSize / 19, -starSize / 2, -starSize / 2);
        ctx.fill(path);

        ctx.fillStyle = "white";
        ctx.shadowColor = "white";
        ctx.shadowBlur = 15;
        ctx.fill();

        ctx.restore();
    }
}

function animateStar() {
    if (Math.abs(starPosition - targetStarPosition) > 0.0001) {
        starPosition += (targetStarPosition - starPosition) * starSpeed; 
        draw();
        animationFrameId = requestAnimationFrame(animateStar);
    } else {
        starPosition = targetStarPosition;
        trail.length = 0; 
        draw(); 
        cancelAnimationFrame(animationFrameId);
    }
}

let currentSectionIndex = 0;
window.addEventListener('scroll', () => {
    let newSectionIndex = currentSectionIndex;
    for (let i = 0; i < sections.length; i++) {
        const sectionElement = document.querySelector(sections[i][0]);
        if (sectionElement && window.scrollY >= sectionElement.offsetTop - window.innerHeight / 1.2) {
            newSectionIndex = i;
        }
    }

    if (newSectionIndex !== currentSectionIndex) {
        currentSectionIndex = newSectionIndex;
        targetStarPosition = currentSectionIndex / (sections.length - 1);

        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
        }
        animateStar();
    }
});

setTimeout(resizeCanvas, 100);
window.addEventListener("resize", resizeCanvas);
// document.addEventListener('DOMContentLoaded', resizeCanvas);

// === ЛОГИКА ДИНАМИЧЕСКОЙ НАВИГАЦИИ (ОСТАВЛЕНО БЕЗ ИЗМЕНЕНИЙ) ===

document.addEventListener('DOMContentLoaded', () => {
    const navbar = document.getElementById('navbar');
    if (!navbar) return; 

    const navLinks = navbar.querySelectorAll('a[href^="#"]'); 
    
    const SCROLL_THRESHOLD = 50; 
    const MOUSE_TOP_THRESHOLD = 100; 

    let isNavigating = false; 
    let lastMouseY = 0; 

    function handleScroll() {
        if (isNavigating) return; 

        const isScrolledDown = window.scrollY > SCROLL_THRESHOLD;

        if (isScrolledDown) {
            navbar.classList.add('nav-hidden-up', 'pointer-events-none');
        } else {
            navbar.classList.remove('nav-hidden-up', 'pointer-events-none');
        }
    }

    function handleMouseMove(e) {
        lastMouseY = e.clientY; 
        
        const isScrolledDown = window.scrollY > SCROLL_THRESHOLD;
        
        if (isScrolledDown) {
            if (e.clientY < MOUSE_TOP_THRESHOLD) {
                navbar.classList.remove('nav-hidden-up', 'pointer-events-none');
            } else {
                navbar.classList.add('nav-hidden-up', 'pointer-events-none');
            }
        }
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navbar.classList.remove('nav-hidden-up', 'pointer-events-none');
            isNavigating = true;
            
            setTimeout(() => {
                isNavigating = false;
                
                const isScrolledDown = window.scrollY > SCROLL_THRESHOLD;

                if (!(isScrolledDown && lastMouseY < MOUSE_TOP_THRESHOLD)) {
                    handleScroll(); 
                }
            }, 800); 
        });
    });

    window.addEventListener('scroll', handleScroll);
    document.body.addEventListener('mousemove', handleMouseMove);

    handleScroll();
});










document.addEventListener('DOMContentLoaded', () => {
    const track = document.querySelector('.carousel-track');
    const slides = Array.from(document.querySelectorAll('.carousel-slide'));
    const container = document.querySelector('.carousel-container'); 
    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');

    let currentSlide = slides.find(slide => slide.classList.contains('current-slide')) || slides[0];
    if (!currentSlide.classList.contains('current-slide')) {
        currentSlide.classList.add('current-slide');
    }

    // [ОСТАЛЬНЫЕ ФУНКЦИИ setTrackPosition И updateNeighborClasses ОСТАЮТСЯ БЕЗ ИЗМЕНЕНИЙ]

    const setTrackPosition = () => {
        // ... (тело функции остается прежним)
        const currentSlideIndex = slides.indexOf(currentSlide);
        const slideElement = slides[currentSlideIndex];
        const slideLeft = slideElement.offsetLeft; 
        const slideWidth = slideElement.offsetWidth;
        const containerWidth = container.offsetWidth;
        const offset = slideLeft + (slideWidth / 2) - (containerWidth / 2);
        track.style.transform = `translateX(-${offset}px)`;
        updateNeighborClasses();
    };
    
    const updateNeighborClasses = () => {
        // ... (тело функции остается прежним)
        slides.forEach(s => s.classList.remove('prev-slide', 'next-slide'));
        const currentIndex = slides.indexOf(currentSlide);
        if (slides.length < 2) return; 
        const nextIndex = (currentIndex + 1) % slides.length;
        const prevIndex = (currentIndex - 1 + slides.length) % slides.length;
        slides[nextIndex].classList.add('next-slide');
        slides[prevIndex].classList.add('prev-slide');
    };

    setTrackPosition();
    window.addEventListener('resize', setTrackPosition);

    const moveToSlide = (targetSlide) => {
        // 1. Убрать класс 'current-slide' со старого слайда
        currentSlide.classList.remove('current-slide');
        
        // 2. Добавить класс 'current-slide' к новому слайду
        targetSlide.classList.add('current-slide');
        
        // 3. Обновить ссылку на текущий слайд
        currentSlide = targetSlide;
        
        // 4. Пересчитать смещение и выполнить CSS-трансформацию (анимацию)
        setTrackPosition(); 
    };

    // --- ИСПРАВЛЕННЫЕ ОБРАБОТЧИКИ СОБЫТИЙ ---

    // Обработчик для кнопки ВПРАВО (Next)
   // Обработчик для кнопки ВПРАВО (Next)
    nextBtn.addEventListener('click', () => {
        const currentIndex = slides.indexOf(currentSlide);
        const nextIndex = (currentIndex + 1) % slides.length; 
        moveToSlide(slides[nextIndex]);
    });

    // Обработчик для кнопки ВЛЕВО (Prev)
    prevBtn.addEventListener('click', () => {
        const currentIndex = slides.indexOf(currentSlide);
        // Зацикливание: если currentIndex = 0, (0 - 1 + length) % length даст последний индекс
        const prevIndex = (currentIndex - 1 + slides.length) % slides.length;
        moveToSlide(slides[prevIndex]);
    });
});